
export interface Photo {
  id: string;
  url: string;
  status: 'pending' | 'approved';
}

export interface Event {
  id:string;
  title: string;
  photos: Photo[];
}

export interface Menfess {
  id: string;
  message: string;
  timestamp: string;
}
