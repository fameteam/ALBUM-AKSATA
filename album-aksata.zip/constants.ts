
import { Event, Menfess } from './types';

export const initialEvents: Event[] = [
    {
        id: 'event-1',
        title: 'Bisikan Alam Liar',
        photos: [
            { id: 'p1-1', url: 'https://picsum.photos/seed/p1-1/800/600', status: 'approved' },
            { id: 'p1-2', url: 'https://picsum.photos/seed/p1-2/800/1000', status: 'approved' },
            { id: 'p1-3', url: 'https://picsum.photos/seed/p1-3/800/700', status: 'approved' },
            { id: 'p1-4', url: 'https://picsum.photos/seed/p1-4/800/650', status: 'approved' },
            { id: 'p1-5', url: 'https://picsum.photos/seed/p1-5/800/900', status: 'approved' },
        ]
    },
    {
        id: 'event-2',
        title: 'Kromatik Perkotaan',
        photos: [
            { id: 'p2-1', url: 'https://picsum.photos/seed/p2-1/800/1100', status: 'approved' },
            { id: 'p2-2', url: 'https://picsum.photos/seed/p2-2/800/600', status: 'approved' },
            { id: 'p2-3', url: 'https://picsum.photos/seed/p2-3/800/750', status: 'approved' },
            { id: 'p2-4', url: 'https://picsum.photos/seed/p2-4/800/600', status: 'approved' },
        ]
    },
];

export const initialMenfess: Menfess[] = [
    {
        id: 'm-1',
        message: 'Melihat semua foto indah ini membuatku ingin lebih sering bepergian. Koleksi yang sangat menginspirasi!',
        timestamp: '2 jam yang lalu'
    },
    {
        id: 'm-2',
        message: 'Acara "Kromatik Perkotaan" dengan sempurna menangkap energi kota. Aku merasa seperti berada di jalanan berlampu neon itu.',
        timestamp: '5 jam yang lalu'
    },
    {
        id: 'm-3',
        message: 'Aplikasi yang keren! Sangat suka dengan konsep kolaboratifnya.',
        timestamp: '1 hari yang lalu'
    }
];
