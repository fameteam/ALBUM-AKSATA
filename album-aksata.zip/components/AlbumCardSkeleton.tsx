
import React from 'react';

const AlbumCardSkeleton = () => {
    return (
        <div className="rounded-lg overflow-hidden shadow-lg bg-[#112240] animate-pulse border border-slate-800">
            <div className="bg-slate-800 h-64 w-full"></div>
            <div className="p-5">
                <div className="h-7 bg-slate-800 rounded w-3/4"></div>
            </div>
        </div>
    );
};

export default AlbumCardSkeleton;
