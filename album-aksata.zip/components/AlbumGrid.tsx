
import React from 'react';
import { Event as Album } from '../types';
import AlbumCard from './AlbumCard';

interface AlbumGridProps {
    albums: Album[];
    onSelectAlbum: (albumId: string) => void;
}

const AlbumGrid = ({ albums, onSelectAlbum }: AlbumGridProps) => {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {albums.map((album) => (
                <AlbumCard key={album.id} album={album} onSelectAlbum={onSelectAlbum} />
            ))}
        </div>
    );
};

export default AlbumGrid;
