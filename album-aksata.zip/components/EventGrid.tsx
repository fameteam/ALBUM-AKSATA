
import React from 'react';
import { Event } from '../types';
import EventCard from './EventCard';
import EventCardSkeleton from './EventCardSkeleton';

interface EventGridProps {
    events: Event[];
    onSelectEvent: (eventId: string) => void;
}

const EventGrid = ({ events, onSelectEvent }: EventGridProps) => {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event) => (
                <EventCard key={event.id} event={event} onSelectEvent={onSelectEvent} />
            ))}
        </div>
    );
};

export default EventGrid;
