import React, { useState } from 'react';
import { KeyRound } from 'lucide-react';

interface LoginPageProps {
    onLogin: (password: string) => void;
    error: string;
}

const LoginPage = ({ onLogin, error }: LoginPageProps) => {
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onLogin(password);
    };

    return (
        <div className="max-w-md mx-auto mt-16 bg-[#112240] p-8 rounded-lg shadow-2xl border border-slate-700">
            <div className="text-center mb-8">
                 <div className="inline-block bg-slate-800 p-4 rounded-full mb-4">
                    <KeyRound size={32} className="text-sky-400"/>
                </div>
                <h1 className="text-2xl sm:text-3xl font-display text-white">Akses Admin</h1>
                <p className="text-slate-400 mt-2">Silakan masukkan kata sandi untuk melanjutkan.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="password-input" className="sr-only">Kata Sandi</label>
                    <input
                        id="password-input"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Masukkan kata sandi"
                        className="w-full p-3 bg-slate-800 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 focus:outline-none transition"
                        required
                    />
                </div>
                
                {error && (
                    <p className="text-red-400 text-sm text-center animate-shake">{error}</p>
                )}
                 
                <div className="text-xs text-slate-500 text-center">
                    Petunjuk: Kata sandinya adalah <span className="font-mono text-slate-400">aksata2024</span>
                </div>

                <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 px-4 rounded-lg transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed"
                >
                    Masuk
                </button>
            </form>
        </div>
    );
};

export default LoginPage;