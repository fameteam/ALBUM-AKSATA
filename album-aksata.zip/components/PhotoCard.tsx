import React from 'react';
import { Photo } from '../types';
import { Trash2 } from 'lucide-react';

interface PhotoCardProps {
    photo: Photo;
    eventId: string;
    isAdmin?: boolean;
    onDeletePhoto?: (eventId: string, photoId: string) => void;
}

const PhotoCard = ({ photo, eventId, isAdmin, onDeletePhoto }: PhotoCardProps) => {
    
    const handleDeleteClick = (e: React.MouseEvent) => {
        e.stopPropagation(); // Prevent card click event
        if (onDeletePhoto) {
            onDeletePhoto(eventId, photo.id);
        }
    };

    return (
        <div className="break-inside-avoid bg-[#112240] rounded-lg shadow-md overflow-hidden group relative border border-slate-800">
             {isAdmin && onDeletePhoto && (
                 <button 
                    onClick={handleDeleteClick}
                    className="absolute top-2 right-2 z-10 p-1.5 bg-slate-900/60 text-slate-200 rounded-full hover:bg-red-500 hover:text-white transition-all"
                    aria-label="Hapus foto"
                 >
                     <Trash2 size={18} />
                 </button>
             )}
            <img src={photo.url} alt={'Sebuah foto dari acara'} className="w-full h-auto object-cover" />
        </div>
    );
};

export default PhotoCard;