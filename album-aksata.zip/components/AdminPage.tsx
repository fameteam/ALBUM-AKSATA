import React, { useState } from 'react';
import { Event, Photo } from '../types';
import { Trash2, Album as AlbumIcon, Image as ImageIcon, Check, X, LoaderCircle, PlusCircle, Edit, Save, Ban } from 'lucide-react';

interface AdminPageProps {
    events: Event[];
    onDeleteEvent: (eventId: string) => void;
    onApprovePhoto: (eventId: string, photoId: string) => void;
    onRejectPhoto: (eventId: string, photoId: string) => void;
    onCreateEvent: (title: string) => void;
    isCreating: boolean;
    onEditEvent: (eventId: string, newTitle: string) => void;
}

type PendingPhoto = Photo & { eventId: string; eventTitle: string };

const StatCard = ({ title, value, icon }: { title: string, value: number, icon: React.ReactNode }) => (
    <div className="bg-[#112240] p-6 rounded-lg shadow-lg flex items-center gap-6 border border-slate-800">
        <div className="bg-slate-800 p-4 rounded-full">
            {icon}
        </div>
        <div>
            <h3 className="text-slate-400 text-sm font-medium">{title}</h3>
            <p className="text-white text-3xl font-bold">{value}</p>
        </div>
    </div>
);

const AdminPage = ({ events, onDeleteEvent, onApprovePhoto, onRejectPhoto, onCreateEvent, isCreating, onEditEvent }: AdminPageProps) => {
    const totalPhotos = events.reduce((acc, event) => acc + event.photos.filter(p => p.status === 'approved').length, 0);
    const pendingPhotos: PendingPhoto[] = events.flatMap(event => 
        event.photos
            .filter(photo => photo.status === 'pending')
            .map(photo => ({ ...photo, eventId: event.id, eventTitle: event.title }))
    );

    const [newEventTitle, setNewEventTitle] = useState('');
    
    const [editingEventId, setEditingEventId] = useState<string | null>(null);
    const [editTitle, setEditTitle] = useState('');

    const handleCreateSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newEventTitle.trim()) {
            alert("Harap berikan judul untuk acara baru.");
            return;
        }
        onCreateEvent(newEventTitle);
        setNewEventTitle('');
    };
    
    const handleStartEdit = (event: Event) => {
        setEditingEventId(event.id);
        setEditTitle(event.title);
    };

    const handleCancelEdit = () => {
        setEditingEventId(null);
        setEditTitle('');
    };

    const handleSaveEdit = () => {
        if (editingEventId && editTitle.trim()) {
            onEditEvent(editingEventId, editTitle);
            handleCancelEdit();
        }
    };

    return (
        <div className="max-w-6xl mx-auto space-y-12">
            <div className="text-center">
                <h1 className="text-3xl sm:text-4xl font-display text-white">Dasbor Admin</h1>
                <p className="text-slate-300 mt-2">Tinjauan dan manajemen koleksi Aksata.</p>
            </div>

            <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <StatCard title="Total Acara" value={events.length} icon={<AlbumIcon size={32} className="text-slate-300"/>} />
                <StatCard title="Total Foto Disetujui" value={totalPhotos} icon={<ImageIcon size={32} className="text-slate-300"/>} />
            </section>

             <section>
                 <h2 className="text-2xl font-display text-white mb-6">Persetujuan Tertunda ({pendingPhotos.length})</h2>
                 {pendingPhotos.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {pendingPhotos.map(photo => (
                            <div key={photo.id} className="bg-[#112240] rounded-lg shadow-lg overflow-hidden flex flex-col border border-slate-800">
                                <img src={photo.url} alt="Menunggu persetujuan" className="w-full h-48 object-cover" />
                                <div className="p-4 flex flex-col flex-grow">
                                    <p className="text-sm text-slate-400 flex-grow">
                                        Untuk Acara: <span className="font-semibold text-slate-300">{photo.eventTitle}</span>
                                    </p>
                                    <div className="flex justify-end gap-2 mt-4">
                                        <button 
                                            onClick={() => onRejectPhoto(photo.eventId, photo.id)}
                                            className="flex items-center gap-1.5 bg-red-500/80 hover:bg-red-600/80 text-white font-semibold py-2 px-3 rounded-md transition-colors text-sm"
                                            aria-label="Tolak foto"
                                        >
                                            <X size={16} /> Tolak
                                        </button>
                                        <button 
                                            onClick={() => onApprovePhoto(photo.eventId, photo.id)}
                                            className="flex items-center gap-1.5 bg-green-500/80 hover:bg-green-600/80 text-white font-semibold py-2 px-3 rounded-md transition-colors text-sm"
                                            aria-label="Setujui foto"
                                        >
                                            <Check size={16} /> Setujui
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                 ) : (
                    <div className="bg-[#112240] rounded-lg p-6 text-center text-slate-400 border border-slate-800">
                        Tidak ada foto yang menunggu persetujuan.
                    </div>
                 )}
            </section>

            <section>
                <h2 className="text-2xl font-display text-white mb-6">Kelola Acara</h2>
                
                <form onSubmit={handleCreateSubmit} className="bg-[#112240] p-6 rounded-lg shadow-lg mb-8 space-y-4 border border-slate-800">
                    <h3 className="text-xl font-bold text-white">Buat Berkas Acara Baru</h3>
                    <div>
                        <label htmlFor="event-title" className="block text-sm font-medium text-slate-300 mb-1">Judul Acara</label>
                        <input
                            id="event-title"
                            type="text"
                            value={newEventTitle}
                            onChange={(e) => setNewEventTitle(e.target.value)}
                            placeholder="cth., Musim Panas di Seminyak"
                            className="w-full p-2 bg-slate-800 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 focus:outline-none"
                            required
                        />
                    </div>
                    <div className="flex justify-end">
                         <button
                            type="submit"
                            disabled={isCreating}
                            className="flex items-center justify-center gap-2 bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed w-48"
                        >
                            {isCreating ? (
                                <>
                                    <LoaderCircle size={20} className="animate-spin" />
                                    Membuat...
                                </>
                            ) : (
                                <>
                                    <PlusCircle size={20} />
                                    Buat Acara
                                </>
                            )}
                        </button>
                    </div>
                </form>

                 <div className="bg-[#112240] rounded-lg shadow-lg overflow-hidden border border-slate-800">
                    <ul className="divide-y divide-slate-800">
                        {events.length > 0 ? events.map(event => (
                            <li key={event.id} className="p-4 hover:bg-slate-800/50 transition-colors">
                                {editingEventId === event.id ? (
                                    <div className="space-y-3">
                                        <input type="text" value={editTitle} onChange={e => setEditTitle(e.target.value)} className="w-full p-2 bg-slate-800 border border-slate-700 rounded-md text-white" />
                                        <div className="flex justify-end gap-2">
                                            <button onClick={handleCancelEdit} className="flex items-center gap-1.5 text-slate-300 hover:text-white font-semibold py-2 px-3 rounded-md transition-colors text-sm"><Ban size={16}/> Batal</button>
                                            <button onClick={handleSaveEdit} className="flex items-center gap-1.5 bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-3 rounded-md transition-colors text-sm"><Save size={16}/> Simpan</button>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="flex items-start justify-between">
                                        <div>
                                            <p className="font-bold text-white">{event.title}</p>
                                            <p className="text-xs text-slate-400 mt-2">{event.photos.filter(p=>p.status === 'approved').length} foto disetujui</p>
                                        </div>
                                        <div className="flex gap-1 flex-shrink-0 ml-4">
                                            <button onClick={() => handleStartEdit(event)} className="p-2 rounded-full text-sky-400 hover:bg-sky-900/50 hover:text-sky-300 transition-colors" aria-label={`Ubah ${event.title}`}><Edit size={18} /></button>
                                            <button onClick={() => onDeleteEvent(event.id)} className="p-2 rounded-full text-red-400 hover:bg-red-900/50 hover:text-red-300 transition-colors" aria-label={`Hapus ${event.title}`}><Trash2 size={18} /></button>
                                        </div>
                                    </div>
                                )}
                            </li>
                        )) : (
                            <li className="p-6 text-center text-slate-400">Tidak ada acara untuk ditampilkan. Buat satu di atas!</li>
                        )}
                    </ul>
                 </div>
            </section>
        </div>
    );
};

export default AdminPage;