
import React from 'react';
import { Event as Album, Photo } from '../types';
import PhotoCard from './PhotoCard';
import { ArrowLeft, CloudUpload } from 'lucide-react';

interface AlbumViewProps {
    album: Album;
    onBack: () => void;
    onAddPhotos: (eventId: string, files: FileList) => void;
    isAdmin: boolean;
    onDeletePhoto: (eventId: string, photoId: string) => void;
}

const AlbumView = ({ album, onBack, onAddPhotos, isAdmin, onDeletePhoto }: AlbumViewProps) => {
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const handleAddClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            onAddPhotos(album.id, e.target.files);
            e.target.value = ''; 
        }
    };

    const approvedPhotos = album.photos.filter(p => p.status === 'approved');
    
    return (
        <div>
            <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
                <button
                    onClick={onBack}
                    className="flex items-center gap-2 text-slate-300 hover:text-sky-400 font-bold transition-colors"
                >
                    <ArrowLeft size={20} />
                    Kembali ke Galeri
                </button>
                 <button
                    onClick={handleAddClick}
                    className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
                >
                    <CloudUpload size={20} />
                    Tambah Foto
                </button>
                <input 
                    type="file" 
                    multiple 
                    accept="image/*"
                    ref={fileInputRef} 
                    onChange={handleFileChange}
                    className="hidden"
                />
            </div>

            <div className="text-center mb-12">
                <h2 className="font-display text-4xl sm:text-5xl font-bold text-white">{album.title}</h2>
            </div>
            
            <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
                {approvedPhotos.map((photo) => (
                    <PhotoCard 
                        key={photo.id} 
                        photo={photo} 
                        eventId={album.id}
                        isAdmin={isAdmin}
                        onDeletePhoto={onDeletePhoto}
                    />
                ))}
            </div>
            {approvedPhotos.length === 0 && (
                 <div className="text-center py-12 text-slate-400">
                    <p>Belum ada foto yang disetujui untuk acara ini.</p>
                    <p className="text-sm mt-2">Unggah beberapa foto dan tunggu persetujuan admin!</p>
                </div>
            )}
        </div>
    );
};

export default AlbumView;
