import React from 'react';
import { Event as Album } from '../types';
import { Image } from 'lucide-react';

interface AlbumCardProps {
    album: Album;
    onSelectAlbum: (albumId: string) => void;
}

const AlbumCard = ({ album, onSelectAlbum }: AlbumCardProps) => {
    const coverPhoto = album.photos.find(p => p.status === 'approved');

    return (
        <div 
            className="group cursor-pointer rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 bg-[#112240] border border-slate-800 hover:border-sky-500"
            onClick={() => onSelectAlbum(album.id)}
        >
            <div className="overflow-hidden h-64 bg-slate-800 flex items-center justify-center">
                {coverPhoto ? (
                    <img 
                        src={coverPhoto.url} 
                        alt={album.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                    />
                ) : (
                    <Image size={48} className="text-slate-600" />
                )}
            </div>
            <div className="p-5 flex justify-between items-center">
                <h3 className="font-display text-xl font-bold text-slate-100 truncate">{album.title}</h3>
                 <div className="text-sm text-slate-400">
                    {album.photos.filter(p => p.status === 'approved').length} foto
                </div>
            </div>
        </div>
    );
};

export default AlbumCard;
