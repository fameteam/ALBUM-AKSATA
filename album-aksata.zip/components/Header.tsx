import React from 'react';
import { Page } from '../App';
import { LogOut } from 'lucide-react';

interface HeaderProps {
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
    isAdminLoggedIn?: boolean;
    onLogout?: () => void;
}

const NavButton = ({ isActive, onClick, children }: { isActive: boolean, onClick: () => void, children: React.ReactNode }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            isActive
                ? 'bg-sky-500 text-white'
                : 'text-slate-300 hover:bg-slate-700 hover:text-sky-400'
        }`}
    >
        {children}
    </button>
);


const Header = ({ currentPage, setCurrentPage, isAdminLoggedIn, onLogout }: HeaderProps) => {
    return (
        <header className="bg-transparent py-6 border-b border-slate-800">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-center sm:text-left">
                     <h1 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-wider">
                        Album Aksata
                    </h1>
                    <p className="text-slate-400 mt-1 text-xs sm:text-sm">Kisah-kisah pilihan melalui lensa Anda</p>
                </div>
                <nav className="flex items-center gap-2">
                    <div className="flex items-center gap-2 p-1 bg-slate-900 rounded-lg">
                        <NavButton isActive={currentPage === 'gallery'} onClick={() => setCurrentPage('gallery')}>
                            Galeri
                        </NavButton>
                        <NavButton isActive={currentPage === 'menfess'} onClick={() => setCurrentPage('menfess')}>
                            Menfess
                        </NavButton>
                        <NavButton isActive={currentPage === 'admin'} onClick={() => setCurrentPage('admin')}>
                            Admin
                        </NavButton>
                    </div>
                    {isAdminLoggedIn && onLogout && (
                         <button
                            onClick={onLogout}
                            className="flex items-center gap-2 ml-2 px-4 py-2 rounded-md text-sm font-medium text-sky-300 bg-sky-900/50 hover:bg-sky-800/70 transition-colors"
                            aria-label="Keluar"
                        >
                            <LogOut size={16} />
                            Keluar
                        </button>
                    )}
                </nav>
            </div>
        </header>
    );
};

export default Header;