import React, { useState } from 'react';
import { Menfess } from '../types';
import { initialMenfess } from '../constants';
import { Send, LoaderCircle, ShieldAlert } from 'lucide-react';
import { moderateMessage } from '../services/geminiService';

const MenfessPage = () => {
    const [messages, setMessages] = useState<Menfess[]>(initialMenfess);
    const [newMessage, setNewMessage] = useState('');
    const [isChecking, setIsChecking] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || isChecking) return;

        setIsChecking(true);
        setError('');

        const moderationResult = await moderateMessage(newMessage.trim());
        
        setIsChecking(false);

        if (moderationResult === 'SAFE') {
            const newEntry: Menfess = {
                id: `m-${Date.now()}`,
                message: newMessage.trim(),
                timestamp: 'Baru saja',
            };
            setMessages(prev => [newEntry, ...prev]);
            setNewMessage('');
        } else {
            setError('Pesan Anda dianggap tidak pantas dan tidak dapat diposting. Harap periksa kembali tulisan Anda.');
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
                <h1 className="text-3xl sm:text-4xl font-display text-white">Papan Pesan</h1>
                <p className="text-slate-300 mt-2">Bagikan pikiran, perasaan, atau kesan Anda dengan komunitas.</p>
            </div>

            <div className="mb-12">
                <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                    <textarea
                        value={newMessage}
                        onChange={(e) => {
                            setNewMessage(e.target.value)
                            if (error) setError('');
                        }}
                        placeholder="Ketik pengakuan Anda di sini..."
                        rows={4}
                        className="w-full p-4 bg-[#112240] border border-slate-700 rounded-lg text-slate-200 placeholder-slate-400 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 focus:outline-none transition-shadow"
                    />
                    {error && (
                        <div className="flex items-center gap-3 text-red-400 p-3 bg-red-900/30 border border-red-500/50 rounded-lg text-sm">
                            <ShieldAlert size={20}/>
                            <span>{error}</span>
                        </div>
                    )}
                    <button
                        type="submit"
                        className="flex items-center justify-center gap-2 bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 px-4 rounded-lg transition-colors disabled:bg-slate-600 disabled:text-slate-400 disabled:cursor-not-allowed self-end w-40"
                        disabled={!newMessage.trim() || isChecking}
                    >
                        {isChecking ? (
                            <>
                                <LoaderCircle size={18} className="animate-spin" />
                                Memeriksa...
                            </>
                        ) : (
                            <>
                                <Send size={18} />
                                Kirim Pesan
                            </>
                        )}
                    </button>
                </form>
            </div>

            <div className="space-y-6">
                {messages.map(menfess => (
                    <div key={menfess.id} className="bg-[#112240] p-6 rounded-lg shadow-md animate-fade-in border border-slate-800">
                        <p className="text-slate-200 text-lg">"{menfess.message}"</p>
                        <p className="text-right text-sm text-slate-400 mt-4">- {menfess.timestamp}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MenfessPage;