import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const parseJsonResponse = <T,>(text: string): T | null => {
    let jsonStr = text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
        jsonStr = match[2].trim();
    }
    try {
        return JSON.parse(jsonStr) as T;
    } catch (e) {
        console.error("Gagal mem-parsing respons JSON:", e);
        return null;
    }
};

export const moderateMessage = async (message: string): Promise<'SAFE' | 'UNSAFE'> => {
    try {
        const prompt = `
            Anda adalah moderator konten yang sangat ketat. Tugas Anda adalah menganalisis pesan dan menentukan apakah pesan tersebut mengandung konten yang tidak pantas.
            Konten yang tidak pantas mencakup, namun tidak terbatas pada: ujaran kebencian, perundungan, pelecehan, kekerasan, konten eksplisit, spam, atau kata-kata kasar dalam Bahasa Indonesia (contoh: goblok, tolol, anjing, kontol, memek, bajingan, dll).
            Balas HANYA dengan 'SAFE' jika pesan dapat diterima, atau 'UNSAFE' jika pesan melanggar kebijakan. Jangan memberikan penjelasan apa pun.
            Pesan: "${message}"
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
            config: { thinkingConfig: { thinkingBudget: 0 } }
        });

        const result = response.text.trim().toUpperCase();

        if (result.includes('UNSAFE')) {
            return 'UNSAFE';
        }
        if (result.includes('SAFE')) {
            return 'SAFE';
        }
        
        console.warn("Pengecekan moderasi mengembalikan nilai tak terduga:", result);
        return 'SAFE'; // Default ke aman jika tidak yakin
    } catch (error) {
        console.error("Error selama moderasi pesan:", error);
        return 'SAFE'; // Default ke aman jika terjadi error API
    }
};
