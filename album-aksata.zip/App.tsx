import React, { useState, useCallback, useEffect } from 'react';
import { Event, Photo } from './types';
import Header from './components/Header';
import EventGrid from './components/EventGrid';
import EventView from './components/EventView';
import MenfessPage from './components/MenfessPage';
import AdminPage from './components/AdminPage';
import LoginPage from './components/LoginPage';
import { initialEvents } from './constants';

export type Page = 'gallery' | 'menfess' | 'admin';

const ADMIN_PASSWORD = 'aksata2024';

const App = () => {
    const [events, setEvents] = useState<Event[]>(initialEvents);
    const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
    const [isCreating, setIsCreating] = useState<boolean>(false);
    const [currentPage, setCurrentPage] = useState<Page>('gallery');
    const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
    const [loginError, setLoginError] = useState<string>('');
    
    useEffect(() => {
        const loggedIn = sessionStorage.getItem('isAdminLoggedIn');
        if (loggedIn === 'true') {
            setIsAdminLoggedIn(true);
        }
    }, []);

    const handleLogin = (password: string) => {
        if (password === ADMIN_PASSWORD) {
            setIsAdminLoggedIn(true);
            sessionStorage.setItem('isAdminLoggedIn', 'true');
            setLoginError('');
        } else {
            setLoginError('Kata sandi salah. Silakan coba lagi.');
        }
    };

    const handleLogout = () => {
        setIsAdminLoggedIn(false);
        sessionStorage.removeItem('isAdminLoggedIn');
        setCurrentPage('gallery');
    };

    const handleCreateEvent = useCallback((title: string) => {
        if (!title.trim()) return;

        setIsCreating(true);
        const newEventId = `event-${Date.now()}`;

        const newEvent: Event = {
            id: newEventId,
            title,
            photos: [],
        };

        setTimeout(() => {
            setEvents(prev => [newEvent, ...prev]);
            setIsCreating(false);
        }, 500);
    }, []);
    
    const handleDeleteEvent = (eventIdToDelete: string) => {
        setEvents(prev => prev.filter(event => event.id !== eventIdToDelete));
        if (selectedEventId === eventIdToDelete) {
            setSelectedEventId(null);
        }
    };

    const handleEditEvent = (eventId: string, newTitle: string) => {
        setEvents(prev => prev.map(event => 
            event.id === eventId 
                ? { ...event, title: newTitle }
                : event
        ));
    };

    const handleDeletePhoto = (eventId: string, photoId: string) => {
        setEvents(prev => prev.map(event =>
            event.id === eventId
                ? { ...event, photos: event.photos.filter(p => p.id !== photoId) }
                : event
        ));
    };

    const handlePhotoUpload = useCallback((eventId: string, files: FileList) => {
        const photoStatus = isAdminLoggedIn ? 'approved' : 'pending';

        const newPhotos: Photo[] = Array.from(files).map((file, index) => ({
            id: `${eventId}-photo-${Date.now()}-${index}`,
            url: URL.createObjectURL(file),
            status: photoStatus,
        }));

        setEvents(prev => prev.map(event => 
            event.id === eventId
                ? { ...event, photos: [...event.photos, ...newPhotos] }
                : event
        ));

        if (!isAdminLoggedIn) {
            alert(`${files.length} foto berhasil diunggah dan sekarang menunggu persetujuan admin.`);
        }
    }, [isAdminLoggedIn]);

    const handleApprovePhoto = useCallback((eventId: string, photoId: string) => {
        setEvents(prev => prev.map(event => 
            event.id === eventId
                ? { 
                    ...event, 
                    photos: event.photos.map(photo => 
                        photo.id === photoId 
                            ? { ...photo, status: 'approved' } 
                            : photo
                    )
                  }
                : event
        ));
    }, []);

    const handleRejectPhoto = useCallback((eventId: string, photoId: string) => {
        setEvents(prev => prev.map(event =>
            event.id === eventId
                ? { ...event, photos: event.photos.filter(photo => photo.id !== photoId) }
                : event
        ));
    }, []);

    const handleSelectEvent = (eventId: string) => {
        setSelectedEventId(eventId);
    };

    const handleBackToGrid = () => {
        setSelectedEventId(null);
    };

    const renderContent = () => {
        switch (currentPage) {
            case 'menfess':
                return <MenfessPage />;
            case 'admin':
                return isAdminLoggedIn ? (
                    <AdminPage 
                        events={events} 
                        onDeleteEvent={handleDeleteEvent} 
                        onApprovePhoto={handleApprovePhoto}
                        onRejectPhoto={handleRejectPhoto}
                        onCreateEvent={handleCreateEvent}
                        isCreating={isCreating}
                        onEditEvent={handleEditEvent}
                    />
                ) : (
                    <LoginPage onLogin={handleLogin} error={loginError} />
                );
            case 'gallery':
            default:
                const selectedEvent = events.find(event => event.id === selectedEventId);
                if (selectedEvent) {
                    return (
                         <EventView 
                            event={selectedEvent} 
                            onBack={handleBackToGrid} 
                            onAddPhotos={handlePhotoUpload}
                            isAdmin={isAdminLoggedIn}
                            onDeletePhoto={handleDeletePhoto}
                        />
                    );
                }
                return (
                    <>
                        <div className="flex justify-between items-center mb-8">
                            <h1 className="text-3xl sm:text-4xl font-display text-slate-100">Galeri Acara Anda</h1>
                        </div>
                        <EventGrid events={events} onSelectEvent={handleSelectEvent} />
                    </>
                );
        }
    }

    return (
        <div className="min-h-screen bg-[#0A192F] text-slate-200">
            <Header 
                currentPage={currentPage} 
                setCurrentPage={setCurrentPage}
                isAdminLoggedIn={isAdminLoggedIn}
                onLogout={handleLogout}
            />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {renderContent()}
            </main>
             <footer className="text-center py-6 text-slate-400 text-sm">
                <p>Album Aksata &copy; {new Date().getFullYear()}</p>
            </footer>
        </div>
    );
};

export default App;